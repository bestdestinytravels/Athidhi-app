"use client";
import { useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";

const NAV = [
  { href: "/dashboard", label: "Dashboard" },
  { href: "/calendar", label: "Calendar" },
  { href: "/enquiries", label: "Enquiries" },
  { href: "/bookings", label: "Bookings" },
];

export default function Shell({
  user,
  children,
}: {
  user: { name: string; role: string };
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const router = useRouter();

  async function signOut() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  }

  return (
    <div className="flex min-h-screen">
      {/* Backdrop - only visible on mobile when the drawer is open; tapping it closes the sidebar */}
      {open && (
        <div
          className="fixed inset-0 bg-black/50 z-[70] lg:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      <aside
        className={`w-[230px] bg-ink text-[#EFEAD9] flex-shrink-0 flex flex-col py-6 fixed lg:static top-0 bottom-0 z-[80] transition-transform duration-200
        ${open ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}`}
      >
        <div className="px-6 pb-5 mb-3 border-b border-white/10">
          <div className="font-display text-2xl text-white">Athidhi</div>
          <div className="text-[11px] text-gold uppercase tracking-widest">Reservation Desk</div>
        </div>
        <nav className="flex flex-col gap-1 px-3">
          {NAV.map((n) => (
            <Link
              key={n.href}
              href={n.href}
              onClick={() => setOpen(false)}
              className={`px-3.5 py-2.5 rounded-lg text-sm font-medium ${
                pathname === n.href ? "bg-gold text-ink font-bold" : "text-[#CFC8B6] hover:bg-white/10 hover:text-white"
              }`}
            >
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="mt-auto px-6 pt-4 border-t border-white/10">
          <div className="text-sm text-white font-semibold">{user.name}</div>
          <div className="text-[11px] text-gold uppercase">{user.role}</div>
          <button onClick={signOut} className="text-sm text-[#CFC8B6] hover:text-white mt-2">Sign out</button>
        </div>
      </aside>

      <div className="flex-1 min-w-0 flex flex-col lg:ml-0">
        <div className="bg-white border-b border-line px-6 py-4 flex items-center justify-between sticky top-0 z-20">
          <div className="flex items-center gap-3">
            <button className="lg:hidden w-9 h-9 rounded-full border border-line" onClick={() => setOpen(true)}>☰</button>
            <h2 className="text-xl font-display">{NAV.find((n) => n.href === pathname)?.label ?? ""}</h2>
          </div>
        </div>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}
