"use client";
import { useEffect, useState } from "react";
import { HALL_LABEL, FOOD_PREF_LABEL, money, niceDate } from "@/lib/constants";

export default function DetailsModal({
  id,
  onClose,
  onEdit,
  onCompleted,
  onCancelled,
}: {
  id: string;
  onClose: () => void;
  onEdit: (booking: any) => void;
  onCompleted: () => void;
  onCancelled: () => void;
}) {
  const [booking, setBooking] = useState<any>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch(`/api/bookings/${id}`).then((r) => r.json()).then((d) => setBooking(d.booking));
  }, [id]);

  async function markCompleted() {
    const res = await fetch(`/api/bookings/${id}/complete`, { method: "POST" });
    if (res.ok) onCompleted();
    else setError((await res.json()).error);
  }
  async function cancelBooking() {
    if (!confirm("Cancel this booking?")) return;
    const res = await fetch(`/api/bookings/${id}/cancel`, { method: "POST" });
    if (res.ok) onCancelled();
    else setError((await res.json()).error);
  }

  if (!booking) return null;
  const balance = booking.totalAmount - booking.advanceAmount;

  return (
    <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-5" onClick={onClose}>
      <div className="bg-white rounded-2xl w-[820px] max-w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center px-6 py-5 border-b border-line">
          <h3 className="text-xl font-display flex items-center gap-2">
            {booking.customerName} <span className={`status-pill pill-${booking.status}`}>{booking.status}</span>
          </h3>
          <button className="text-muted text-xl" onClick={onClose}>✕</button>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-2 gap-x-5 gap-y-2.5 text-sm mb-4">
            <div><div className="text-[11px] uppercase text-muted">Hall allocated</div>{HALL_LABEL[booking.hallAllocation]}</div>
            <div><div className="text-[11px] uppercase text-muted">Function</div>{booking.functionType}</div>
            <div><div className="text-[11px] uppercase text-muted">Event date</div>{niceDate(booking.eventDate.slice(0, 10))}</div>
            <div><div className="text-[11px] uppercase text-muted">Booking slot</div>{booking.slot}</div>
            <div><div className="text-[11px] uppercase text-muted">Guests</div>{booking.guests}</div>
            <div><div className="text-[11px] uppercase text-muted">Food / Menu</div>{FOOD_PREF_LABEL[booking.foodPref]} · {booking.menuPackage}</div>
            <div><div className="text-[11px] uppercase text-muted">Mobile</div>{booking.mobile}</div>
            <div><div className="text-[11px] uppercase text-muted">Location</div>{booking.location || "—"}</div>
            <div><div className="text-[11px] uppercase text-muted">Source</div>{booking.source || "—"}</div>
          </div>
          <div className="bg-ivory rounded-lg p-4 text-sm space-y-1.5">
            <div className="flex justify-between"><span>Total package</span><b>{money(booking.totalAmount)}</b></div>
            <div className="flex justify-between"><span>Advance paid ({booking.paymentMode})</span><b>{money(booking.advanceAmount)}</b></div>
            <div className={`flex justify-between ${balance > 0 ? "text-red" : "text-green"}`}><span>Balance due</span><b>{money(balance)}</b></div>
          </div>
          {booking.remarks && <p className="text-sm mt-3"><b>Remarks:</b> {booking.remarks}</p>}

          <h4 className="text-sm font-semibold mt-5 mb-2">Customer timeline</h4>
          <div className="border-l-2 border-line pl-4 space-y-3">
            {booking.history?.map((h: any) => (
              <div key={h.id} className="text-sm relative before:content-[''] before:absolute before:-left-[21px] before:top-1 before:w-2 before:h-2 before:rounded-full before:bg-gold">
                <b>{h.action}</b>
                <div className="text-[11px] text-muted">{new Date(h.createdAt).toLocaleDateString("en-IN")}{h.note ? ` · ${h.note}` : ""}</div>
              </div>
            ))}
          </div>
          {error && <p className="text-red text-sm mt-3">{error}</p>}
        </div>
        <div className="px-6 py-4 border-t border-line flex justify-end gap-2.5">
          <button className="btn btn-outline" onClick={() => onEdit(booking)}>Edit</button>
          {booking.status === "Confirmed" && (
            <>
              <button className="btn btn-outline" onClick={markCompleted}>Mark completed</button>
              <button className="btn btn-danger" onClick={cancelBooking}>Cancel booking</button>
            </>
          )}
          <button className="btn btn-gold" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
}
