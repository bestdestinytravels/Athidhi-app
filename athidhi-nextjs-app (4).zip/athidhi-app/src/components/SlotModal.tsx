"use client";
import { HALL_LABEL, niceDate } from "@/lib/constants";

type SlotBooking = {
  id: string;
  customerName: string;
  functionType: string;
  guests: number;
  hallAllocation: string;
  status: string;
};

export default function SlotModal({
  date,
  slot,
  hall1,
  hall2,
  bookings,
  onClose,
  onConvert,
  onEdit,
  onDelete,
  onViewDetails,
  onAddNew,
}: {
  date: string;
  slot: string;
  hall1: "green" | "orange" | "red" | "grey";
  hall2: "green" | "orange" | "red" | "grey";
  bookings: SlotBooking[];
  onClose: () => void;
  onConvert: (id: string) => void;
  onEdit: (id: string) => void;
  onDelete: (id: string) => void;
  onViewDetails: (id: string) => void;
  onAddNew: () => void;
}) {
  const chipClass: Record<string, string> = {
    green: "bg-greenBg text-green",
    orange: "bg-orangeBg text-orange",
    red: "bg-redBg text-red",
    grey: "bg-greyBg text-muted",
  };
  const chipLabel: Record<string, string> = { green: "Available", orange: "Tentative", red: "Booked", grey: "Past" };
  const bothBooked = hall1 === "red" && hall2 === "red";
  const active = bookings.filter((b) => b.status !== "Lost");

  return (
    <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-5" onClick={onClose}>
      <div className="bg-white rounded-2xl w-[640px] max-w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center px-6 py-5 border-b border-line">
          <h3 className="text-xl font-display">{slot} — {niceDate(date)}</h3>
          <button className="text-muted text-xl" onClick={onClose}>✕</button>
        </div>
        <div className="p-6">
          <div className="flex gap-2.5 mb-4">
            <div className={`flex-1 rounded-lg px-3.5 py-2.5 text-sm font-semibold flex justify-between ${chipClass[hall1]}`}>
              <span>Hall 1</span><span>{chipLabel[hall1]}</span>
            </div>
            <div className={`flex-1 rounded-lg px-3.5 py-2.5 text-sm font-semibold flex justify-between ${chipClass[hall2]}`}>
              <span>Hall 2</span><span>{chipLabel[hall2]}</span>
            </div>
          </div>

          {active.length === 0 && <p className="text-muted text-sm">No enquiries or bookings for this slot yet.</p>}

          {active.map((b) => (
            <div key={b.id} className="border border-line rounded-xl p-4 mb-2.5 flex justify-between gap-3.5">
              <div>
                <h4 className="font-semibold text-sm flex items-center gap-1.5">
                  {b.customerName} <span className={`status-pill pill-${b.status}`}>{b.status}</span>
                </h4>
                <div className="text-xs text-muted mt-1">{HALL_LABEL[b.hallAllocation]} · {b.functionType} · {b.guests} guests</div>
              </div>
              <div className="flex flex-col gap-1.5 flex-shrink-0">
                {b.status === "Enquiry" ? (
                  <button className="btn btn-gold !py-1.5 !px-3 !text-xs" onClick={() => onConvert(b.id)}>Convert</button>
                ) : (
                  <button className="btn btn-gold !py-1.5 !px-3 !text-xs" onClick={() => onViewDetails(b.id)}>View details</button>
                )}
                <button className="btn btn-outline !py-1.5 !px-3 !text-xs" onClick={() => onEdit(b.id)}>Edit</button>
                {b.status === "Enquiry" && (
                  <button className="btn btn-danger !py-1.5 !px-3 !text-xs" onClick={() => onDelete(b.id)}>Delete</button>
                )}
              </div>
            </div>
          ))}

          {bothBooked ? (
            <p className="text-sm text-muted mt-3.5">Both halls are fully booked for this slot.</p>
          ) : (
            <button className="btn btn-outline w-full mt-3.5" onClick={onAddNew}>+ New enquiry / booking for this slot</button>
          )}
        </div>
        <div className="px-6 py-4 border-t border-line flex justify-end">
          <button className="btn btn-outline" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
}
