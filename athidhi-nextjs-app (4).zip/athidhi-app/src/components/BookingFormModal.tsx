"use client";
import { useState } from "react";
import { FUNCTION_TYPES, SLOTS, FOOD_PREFS, FOOD_PREF_LABEL, MENU_PACKAGES, SOURCES, PAY_MODES, GUEST_THRESHOLD, HALL_LABEL, money } from "@/lib/constants";

export type BookingDraft = {
  id?: string;
  customerName?: string;
  mobile?: string;
  location?: string;
  functionType?: string;
  eventDate?: string;
  slot?: string;
  guests?: number;
  hallAllocation?: string; // used only to derive an initial hallId when editing
  foodPref?: string;
  menuPackage?: string;
  specialReq?: string;
  totalAmount?: number;
  advanceAmount?: number;
  paymentMode?: string;
  source?: string;
  remarks?: string;
  status?: string;
};

export default function BookingFormModal({
  draft,
  mode, // "create" | "edit"
  onClose,
  onSaved,
}: {
  draft: BookingDraft;
  mode: "create" | "edit";
  onClose: () => void;
  onSaved: () => void;
}) {
  const initialHallId = draft.hallAllocation === "Hall2" ? 2 : 1;
  const [form, setForm] = useState({
    customerName: draft.customerName ?? "",
    mobile: draft.mobile ?? "",
    location: draft.location ?? "",
    functionType: draft.functionType ?? FUNCTION_TYPES[0],
    eventDate: draft.eventDate ?? "",
    slot: draft.slot ?? SLOTS[0],
    guests: draft.guests != null ? String(draft.guests) : "",
    hallId: initialHallId,
    foodPref: draft.foodPref ?? FOOD_PREFS[0],
    menuPackage: draft.menuPackage ?? MENU_PACKAGES[0],
    specialReq: draft.specialReq ?? "",
    totalAmount: draft.totalAmount != null ? String(draft.totalAmount) : "0",
    advanceAmount: draft.advanceAmount != null ? String(draft.advanceAmount) : "0",
    paymentMode: draft.paymentMode ?? PAY_MODES[0],
    source: draft.source ?? SOURCES[0],
    remarks: draft.remarks ?? "",
  });
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const guestsNum = Number(form.guests) || 0;
  const bothHalls = guestsNum > GUEST_THRESHOLD;
  const balance = (Number(form.totalAmount) || 0) - (Number(form.advanceAmount) || 0);

  function update(key: string, value: string | number) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  function validate(): boolean {
    if (!form.customerName || !form.mobile || !form.eventDate || !form.slot || !guestsNum) {
      setError("Please fill in customer name, mobile, event date, slot and guest count.");
      return false;
    }
    if (!/^\d{10}$/.test(form.mobile)) {
      setError("Mobile number must be 10 digits.");
      return false;
    }
    setError("");
    return true;
  }

  async function submit(statusToSave: "Enquiry" | "Confirmed") {
    if (!validate()) return;
    setSaving(true);
    setError("");

    const payload = { ...form, guests: guestsNum, status: statusToSave };
    const url = mode === "edit" ? `/api/bookings/${draft.id}` : "/api/bookings";
    const method = mode === "edit" ? "PATCH" : "POST";

    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    setSaving(false);

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error || "Something went wrong. Please try again.");
      return;
    }
    onSaved();
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-5" onClick={onClose}>
      <div className="bg-white rounded-2xl w-[820px] max-w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center px-6 py-5 border-b border-line sticky top-0 bg-white">
          <h3 className="text-xl font-display">{mode === "edit" ? "Edit enquiry" : "New enquiry / booking"}</h3>
          <button className="text-muted text-xl" onClick={onClose}>✕</button>
        </div>

        <div className="p-6 space-y-5">
          <fieldset className="border border-line rounded-xl p-4">
            <legend className="text-xs font-bold text-goldDeep px-1.5">Customer</legend>
            <div className="grid grid-cols-2 gap-4">
              <div><label className="label">Customer name *</label><input className="input" value={form.customerName} onChange={(e) => update("customerName", e.target.value)} /></div>
              <div><label className="label">Mobile number *</label><input className="input" value={form.mobile} onChange={(e) => update("mobile", e.target.value)} /></div>
              <div className="col-span-2"><label className="label">Location</label><input className="input" placeholder="Locality / town / city" value={form.location} onChange={(e) => update("location", e.target.value)} /></div>
            </div>
          </fieldset>

          <fieldset className="border border-line rounded-xl p-4">
            <legend className="text-xs font-bold text-goldDeep px-1.5">Event details</legend>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label">Function type</label>
                <select className="input" value={form.functionType} onChange={(e) => update("functionType", e.target.value)}>
                  {FUNCTION_TYPES.map((f) => <option key={f}>{f}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Booking slot *</label>
                <select className="input" value={form.slot} onChange={(e) => update("slot", e.target.value)}>
                  {SLOTS.map((s) => <option key={s}>{s}</option>)}
                </select>
              </div>
              <div><label className="label">Event date *</label><input type="date" className="input" value={form.eventDate} onChange={(e) => update("eventDate", e.target.value)} /></div>
              <div><label className="label">Expected guests *</label><input type="number" min={1} className="input" value={form.guests} onChange={(e) => update("guests", e.target.value)} /></div>

              {!bothHalls ? (
                <div>
                  <label className="label">Hall</label>
                  <select className="input" value={form.hallId} onChange={(e) => update("hallId", Number(e.target.value))}>
                    <option value={1}>Hall 1</option>
                    <option value={2}>Hall 2</option>
                  </select>
                </div>
              ) : (
                <div className="flex items-center">
                  <div className="bg-orangeBg text-orange text-xs font-semibold rounded-lg px-3 py-2.5">
                    Guest count exceeds {GUEST_THRESHOLD}. Both halls will be reserved automatically.
                  </div>
                </div>
              )}

              <div>
                <label className="label">Food preference</label>
                <select className="input" value={form.foodPref} onChange={(e) => update("foodPref", e.target.value)}>
                  {FOOD_PREFS.map((f) => <option key={f} value={f}>{FOOD_PREF_LABEL[f]}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Menu package</label>
                <select className="input" value={form.menuPackage} onChange={(e) => update("menuPackage", e.target.value)}>
                  {MENU_PACKAGES.map((m) => <option key={m}>{m}</option>)}
                </select>
              </div>
              <div className="col-span-2"><label className="label">Special requirements</label><textarea className="input" rows={2} value={form.specialReq} onChange={(e) => update("specialReq", e.target.value)} /></div>
            </div>
          </fieldset>

          <fieldset className="border border-line rounded-xl p-4">
            <legend className="text-xs font-bold text-goldDeep px-1.5">Commercials</legend>
            <div className="grid grid-cols-2 gap-4">
              <div><label className="label">Total package amount (₹)</label><input type="number" min={0} className="input" value={form.totalAmount} onChange={(e) => update("totalAmount", e.target.value)} /></div>
              <div><label className="label">Advance amount (₹)</label><input type="number" min={0} className="input" value={form.advanceAmount} onChange={(e) => update("advanceAmount", e.target.value)} /></div>
              <div>
                <label className="label">Advance payment mode</label>
                <select className="input" value={form.paymentMode} onChange={(e) => update("paymentMode", e.target.value)}>
                  {PAY_MODES.map((m) => <option key={m}>{m}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Source of lead</label>
                <select className="input" value={form.source} onChange={(e) => update("source", e.target.value)}>
                  {SOURCES.map((s) => <option key={s}>{s}</option>)}
                </select>
              </div>
              <div className="col-span-2"><label className="label">Remarks</label><textarea className="input" rows={2} value={form.remarks} onChange={(e) => update("remarks", e.target.value)} /></div>
            </div>
            <div className="flex justify-between bg-ivory rounded-lg px-4 py-3 mt-3 text-sm">
              <span>Balance amount</span>
              <b className="font-display text-base">{money(balance)}</b>
            </div>
          </fieldset>

          {error && <p className="text-red text-sm">{error}</p>}
        </div>

        <div className="px-6 py-4 border-t border-line flex justify-end gap-2.5">
          <button className="btn btn-outline" onClick={onClose}>Cancel</button>
          {mode === "edit" ? (
            <button className="btn btn-gold" disabled={saving} onClick={() => submit(draft.status === "Confirmed" ? "Confirmed" : "Enquiry")}>
              {saving ? "Saving…" : "Save changes"}
            </button>
          ) : (
            <>
              <button className="btn btn-outline" disabled={saving} onClick={() => submit("Enquiry")}>Save as enquiry</button>
              <button className="btn btn-gold" disabled={saving} onClick={() => submit("Confirmed")}>
                {saving ? "Saving…" : "Save & confirm booking"}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
