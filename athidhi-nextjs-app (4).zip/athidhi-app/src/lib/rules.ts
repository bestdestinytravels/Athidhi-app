import { HallAllocation, BookingStatus } from "@prisma/client";
import { prisma } from "./prisma";

export const GUEST_THRESHOLD = 250;

/** Which hall numbers (1, 2, or both) a given allocation occupies. */
export function hallNumsFor(alloc: HallAllocation): number[] {
  if (alloc === "BothHalls") return [1, 2];
  if (alloc === "Hall1") return [1];
  return [2];
}

/** Decide the hall allocation from guest count + the admin's chosen hall (1 or 2). */
export function allocationFor(guests: number, chosenHall: 1 | 2): HallAllocation {
  if (guests > GUEST_THRESHOLD) return "BothHalls";
  return chosenHall === 1 ? "Hall1" : "Hall2";
}

/**
 * Checks whether any CONFIRMED or COMPLETED booking already occupies one of the
 * given hall numbers, on the given date + slot. Optionally excludes one booking id
 * (used when editing an existing booking so it doesn't conflict with itself).
 */
export async function hasConfirmedConflict(
  hallNums: number[],
  eventDate: Date,
  slot: "Morning" | "Evening",
  excludeId?: string
): Promise<boolean> {
  const candidates = await prisma.booking.findMany({
    where: {
      eventDate,
      slot,
      status: { in: ["Confirmed", "Completed"] },
      ...(excludeId ? { id: { not: excludeId } } : {}),
    },
    select: { hallAllocation: true },
  });
  return candidates.some((c) => hallNumsFor(c.hallAllocation).some((h) => hallNums.includes(h)));
}

/**
 * When a booking is confirmed, any other still-open enquiry that overlaps the
 * same date + slot + hall(s) is automatically moved to "Lost" (reason: Hall Booked).
 */
export async function rejectOverlappingEnquiries(confirmed: {
  id: string;
  eventDate: Date;
  slot: "Morning" | "Evening";
  hallAllocation: HallAllocation;
}) {
  const occupied = hallNumsFor(confirmed.hallAllocation);
  const openEnquiries = await prisma.booking.findMany({
    where: {
      id: { not: confirmed.id },
      eventDate: confirmed.eventDate,
      slot: confirmed.slot,
      status: "Enquiry",
    },
  });
  for (const enquiry of openEnquiries) {
    if (hallNumsFor(enquiry.hallAllocation).some((h) => occupied.includes(h))) {
      await prisma.booking.update({
        where: { id: enquiry.id },
        data: {
          status: "Lost" as BookingStatus,
          lostReason: "Hall Booked",
          history: {
            create: { action: "Marked lost", note: "Hall booked by another customer" },
          },
        },
      });
    }
  }
}

export type HallSlotStatus = "green" | "orange" | "red" | "grey";

/** Status of one hall, on one date, in one slot - matches the calendar's dot colors. */
export function computeHallSlotStatus(
  hallNum: number,
  bookingsOnThatDateSlot: { hallAllocation: HallAllocation; status: BookingStatus }[],
  isPast: boolean
): HallSlotStatus {
  if (isPast) return "grey";
  const relevant = bookingsOnThatDateSlot.filter((b) => hallNumsFor(b.hallAllocation).includes(hallNum));
  if (relevant.some((b) => b.status === "Confirmed" || b.status === "Completed")) return "red";
  if (relevant.some((b) => b.status === "Enquiry")) return "orange";
  return "green";
}
