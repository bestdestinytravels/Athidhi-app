export const SLOTS = ["Morning", "Evening"] as const;
export const FUNCTION_TYPES = [
  "Wedding", "Reception", "Birthday", "Naming Ceremony", "Corporate", "Engagement", "Anniversary", "Others",
];
export const FOOD_PREFS = ["Veg", "NonVeg"] as const;
export const FOOD_PREF_LABEL: Record<string, string> = { Veg: "Veg", NonVeg: "Non-Veg" };
export const MENU_PACKAGES = ["Silver", "Gold", "Platinum"] as const;
export const SOURCES = ["Walk-in", "Phone", "WhatsApp", "Google", "Facebook", "Instagram", "Reference"];
export const PAY_MODES = ["Cash", "UPI", "Credit Card", "Bank Transfer"];
export const GUEST_THRESHOLD = 250;

export const HALL_LABEL: Record<string, string> = {
  Hall1: "Hall 1",
  Hall2: "Hall 2",
  BothHalls: "Both Halls",
};

export function money(n: number | null | undefined) {
  return "₹" + Number(n || 0).toLocaleString("en-IN");
}

export function niceDate(str: string) {
  if (!str) return "—";
  const d = new Date(str + "T00:00:00");
  return d.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}
