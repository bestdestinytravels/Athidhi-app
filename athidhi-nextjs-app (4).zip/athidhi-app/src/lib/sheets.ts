import { google } from "googleapis";
import type { Booking } from "@prisma/client";

const SHEET_NAME = "Bookings";
const HEADER = [
  "Booking ID",
  "Customer",
  "Mobile",
  "Location",
  "Function",
  "Event Date",
  "Booking Slot",
  "Hall Allocated",
  "Guests",
  "Food Preference",
  "Menu Package",
  "Advance",
  "Total",
  "Balance",
  "Status",
  "Updated At",
];

function isConfigured() {
  return Boolean(
    process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL &&
      process.env.GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY &&
      process.env.GOOGLE_SHEET_ID
  );
}

function getClient() {
  const auth = new google.auth.JWT({
    email: process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL,
    // Render environments often store the key with literal \n sequences - convert them back to real newlines.
    key: process.env.GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY?.replace(/\\n/g, "\n"),
    scopes: ["https://www.googleapis.com/auth/spreadsheets"],
  });
  return google.sheets({ version: "v4", auth });
}

function toRow(b: Booking): string[] {
  const eventDate = new Date(b.eventDate).toISOString().slice(0, 10);
  const hallLabel = b.hallAllocation === "BothHalls" ? "Both Halls" : b.hallAllocation === "Hall1" ? "Hall 1" : "Hall 2";
  const foodLabel = b.foodPref === "NonVeg" ? "Non-Veg" : "Veg";
  return [
    b.id,
    b.customerName,
    b.mobile,
    b.location ?? "",
    b.functionType,
    eventDate,
    b.slot,
    hallLabel,
    String(b.guests),
    foodLabel,
    b.menuPackage,
    String(b.advanceAmount),
    String(b.totalAmount),
    String(b.totalAmount - b.advanceAmount),
    b.status,
    new Date().toISOString(),
  ];
}

/**
 * Appends a new row, or updates the existing row for this booking if one is
 * already there (matched by Booking ID in column A). Never throws - a Sheets
 * outage should never block a booking from saving to the real database.
 */
export async function syncBookingToSheet(booking: Booking) {
  if (!isConfigured()) return;
  try {
    const sheets = getClient();
    const spreadsheetId = process.env.GOOGLE_SHEET_ID!;

    const existing = await sheets.spreadsheets.values.get({
      spreadsheetId,
      range: `${SHEET_NAME}!A:A`,
    });
    const ids = existing.data.values?.map((r) => r[0]) ?? [];
    if (ids.length === 0) {
      await sheets.spreadsheets.values.append({
        spreadsheetId,
        range: `${SHEET_NAME}!A1`,
        valueInputOption: "RAW",
        requestBody: { values: [HEADER] },
      });
    }

    const rowIndex = ids.indexOf(booking.id);
    const row = toRow(booking);

    if (rowIndex === -1) {
      await sheets.spreadsheets.values.append({
        spreadsheetId,
        range: `${SHEET_NAME}!A1`,
        valueInputOption: "RAW",
        insertDataOption: "INSERT_ROWS",
        requestBody: { values: [row] },
      });
    } else {
      const sheetRowNumber = rowIndex + 1; // ids is 0-indexed and rows are 1-indexed, so this already points at the right row
      await sheets.spreadsheets.values.update({
        spreadsheetId,
        range: `${SHEET_NAME}!A${sheetRowNumber}:P${sheetRowNumber}`,
        valueInputOption: "RAW",
        requestBody: { values: [row] },
      });
    }
  } catch (err) {
    console.error("Google Sheets sync failed (booking was still saved to the database):", err);
  }
}
