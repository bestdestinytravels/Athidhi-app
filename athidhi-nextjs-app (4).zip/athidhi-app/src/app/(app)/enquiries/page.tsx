"use client";
import { useEffect, useState } from "react";
import { HALL_LABEL, niceDate } from "@/lib/constants";
import BookingFormModal, { BookingDraft } from "@/components/BookingFormModal";

export default function EnquiriesPage() {
  const [rows, setRows] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");
  const [editDraft, setEditDraft] = useState<{ draft: BookingDraft; mode: "edit" } | null>(null);

  function load() {
    const params = new URLSearchParams({ status: status || "Enquiry,Lost" });
    if (search) params.set("search", search);
    fetch(`/api/bookings?${params}`).then((r) => r.json()).then((d) => setRows(d.bookings || []));
  }
  useEffect(() => { load(); }, [search, status]);

  async function convert(id: string) {
    const res = await fetch(`/api/bookings/${id}/convert`, { method: "POST" });
    if (res.ok) load(); else alert((await res.json()).error);
  }

  return (
    <div className="panel">
      <div className="flex flex-wrap gap-2.5 mb-4">
        <input className="input !w-56" placeholder="Search name or mobile..." value={search} onChange={(e) => setSearch(e.target.value)} />
        <select className="input !w-48" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">All statuses</option>
          <option value="Enquiry">Enquiry</option>
          <option value="Lost">Lost opportunity</option>
        </select>
      </div>

      {rows.length === 0 ? (
        <div className="text-center py-12 text-muted">No enquiries match your filters.</div>
      ) : (
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-[11px] uppercase text-muted border-b-2 border-line">
              <th className="py-2.5">Customer</th><th>Hall</th><th>Slot</th><th>Function</th><th>Event date</th><th>Guests</th><th>Source</th><th>Status</th><th></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-b border-line hover:bg-ivory">
                <td className="py-3"><b>{r.customerName}</b><br /><span className="text-xs text-muted">{r.mobile}</span></td>
                <td>{HALL_LABEL[r.hallAllocation]}</td>
                <td>{r.slot}</td>
                <td>{r.functionType}</td>
                <td>{niceDate(r.eventDate.slice(0, 10))}</td>
                <td>{r.guests}</td>
                <td>{r.source}</td>
                <td><span className={`status-pill pill-${r.status}`}>{r.status}</span></td>
                <td>
                  <div className="flex gap-1.5">
                    <button className="btn btn-outline !py-1 !px-2.5 !text-xs" onClick={() => setEditDraft({ draft: { ...r, eventDate: r.eventDate.slice(0, 10) }, mode: "edit" })}>View</button>
                    {r.status === "Enquiry" && <button className="btn btn-gold !py-1 !px-2.5 !text-xs" onClick={() => convert(r.id)}>Convert</button>}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {editDraft && (
        <BookingFormModal draft={editDraft.draft} mode="edit" onClose={() => setEditDraft(null)} onSaved={() => { setEditDraft(null); load(); }} />
      )}
    </div>
  );
}
