"use client";
import { useEffect, useState } from "react";
import { HALL_LABEL, money, niceDate } from "@/lib/constants";
import DetailsModal from "@/components/DetailsModal";
import BookingFormModal, { BookingDraft } from "@/components/BookingFormModal";

export default function BookingsPage() {
  const [rows, setRows] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");
  const [detailsId, setDetailsId] = useState<string | null>(null);
  const [editDraft, setEditDraft] = useState<{ draft: BookingDraft; mode: "edit" } | null>(null);

  function load() {
    const params = new URLSearchParams({ status: status || "Confirmed,Completed,Cancelled" });
    if (search) params.set("search", search);
    fetch(`/api/bookings?${params}`).then((r) => r.json()).then((d) => setRows(d.bookings || []));
  }
  useEffect(() => { load(); }, [search, status]);

  function exportCsv() {
    const header = ["Customer", "Mobile", "Location", "Function", "Event Date", "Booking Slot", "Hall Allocated", "Guests", "Food Preference", "Menu Package", "Advance", "Total", "Balance", "Status"];
    const field = (v: any) => `"${String(v ?? "").replace(/"/g, '""')}"`;
    const lines = [header.join(",")].concat(
      rows.map((r) => [
        r.customerName, r.mobile, r.location, r.functionType, r.eventDate.slice(0, 10), r.slot, HALL_LABEL[r.hallAllocation],
        r.guests, r.foodPref, r.menuPackage, r.advanceAmount, r.totalAmount, r.totalAmount - r.advanceAmount, r.status,
      ].map(field).join(","))
    );
    const blob = new Blob([lines.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "athidhi-bookings.csv"; a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="panel">
      <div className="flex flex-wrap gap-2.5 mb-4">
        <input className="input !w-56" placeholder="Search name or mobile..." value={search} onChange={(e) => setSearch(e.target.value)} />
        <select className="input !w-48" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">All statuses</option>
          <option value="Confirmed">Confirmed</option>
          <option value="Completed">Completed</option>
          <option value="Cancelled">Cancelled</option>
        </select>
        <button className="btn btn-outline" onClick={exportCsv}>Export CSV</button>
      </div>

      {rows.length === 0 ? (
        <div className="text-center py-12 text-muted">No bookings match your filters.</div>
      ) : (
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-[11px] uppercase text-muted border-b-2 border-line">
              <th className="py-2.5">Customer</th><th>Hall</th><th>Slot</th><th>Function</th><th>Event date</th><th>Guests</th><th>Advance</th><th>Balance</th><th>Status</th><th></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-b border-line hover:bg-ivory">
                <td className="py-3"><b>{r.customerName}</b><br /><span className="text-xs text-muted">{r.mobile}</span></td>
                <td>{HALL_LABEL[r.hallAllocation]}</td>
                <td>{r.slot}</td>
                <td>{r.functionType}</td>
                <td>{niceDate(r.eventDate.slice(0, 10))}</td>
                <td>{r.guests}</td>
                <td>{money(r.advanceAmount)}</td>
                <td>{money(r.totalAmount - r.advanceAmount)}</td>
                <td><span className={`status-pill pill-${r.status}`}>{r.status}</span></td>
                <td><button className="btn btn-outline !py-1 !px-2.5 !text-xs" onClick={() => setDetailsId(r.id)}>View</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {detailsId && (
        <DetailsModal
          id={detailsId}
          onClose={() => setDetailsId(null)}
          onEdit={(b) => { setDetailsId(null); setEditDraft({ draft: { ...b, eventDate: b.eventDate.slice(0, 10) }, mode: "edit" }); }}
          onCompleted={() => { setDetailsId(null); load(); }}
          onCancelled={() => { setDetailsId(null); load(); }}
        />
      )}
      {editDraft && (
        <BookingFormModal draft={editDraft.draft} mode="edit" onClose={() => setEditDraft(null)} onSaved={() => { setEditDraft(null); load(); }} />
      )}
    </div>
  );
}
