"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { HALL_LABEL, money, niceDate } from "@/lib/constants";

export default function DashboardPage() {
  const [bookings, setBookings] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/bookings").then((r) => r.json()).then((d) => { setBookings(d.bookings || []); setLoading(false); });
  }, []);

  if (loading) return <p className="text-muted text-sm">Loading…</p>;

  const now = new Date();
  const todayStr = now.toISOString().slice(0, 10);

  const todaysEnquiries = bookings.filter((b) => b.createdAt.slice(0, 10) === todayStr && b.status === "Enquiry").length;
  const todaysBookings = bookings.filter((b) => b.createdAt.slice(0, 10) === todayStr && (b.status === "Confirmed" || b.status === "Completed")).length;
  const pending = bookings.filter((b) => b.status === "Enquiry").length;
  const confirmed = bookings.filter((b) => b.status === "Confirmed").length;

  const monthRevenue = bookings
    .filter((b) => (b.status === "Confirmed" || b.status === "Completed") && new Date(b.eventDate).getMonth() === now.getMonth() && new Date(b.eventDate).getFullYear() === now.getFullYear())
    .reduce((s, b) => s + Number(b.totalAmount || 0), 0);

  const todayMidnight = new Date();
  todayMidnight.setHours(0, 0, 0, 0);
  const upcoming = bookings
    .filter((b) => b.status === "Confirmed")
    .filter((b) => { const diff = Math.round((new Date(b.eventDate).getTime() - todayMidnight.getTime()) / 86400000); return diff >= 0 && diff <= 3; })
    .sort((a, b) => a.eventDate.localeCompare(b.eventDate));

  const paymentsDue = bookings.filter((b) => b.status === "Confirmed" && (b.totalAmount - b.advanceAmount) > 0);

  const kpis = [
    { label: "Today's Enquiries", val: todaysEnquiries, sub: "New enquiries logged today" },
    { label: "Today's Bookings", val: todaysBookings, sub: "Confirmed / created today" },
    { label: "Pending Confirmations", val: pending, sub: "Open enquiries awaiting advance" },
    { label: "Confirmed Bookings", val: confirmed, sub: "Active confirmed events" },
    { label: "Monthly Revenue", val: money(monthRevenue), sub: new Date().toLocaleDateString("en-IN", { month: "long" }) + " package value" },
    { label: "Total Records", val: bookings.length, sub: "All-time enquiries & bookings" },
  ];

  return (
    <div>
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        {kpis.map((k) => (
          <div key={k.label} className="bg-white rounded-2xl shadow-sm p-5 border-l-4 border-gold">
            <div className="text-[11px] uppercase tracking-wide text-muted font-semibold">{k.label}</div>
            <div className="font-display text-2xl mt-1.5">{k.val}</div>
            <div className="text-xs text-muted mt-1">{k.sub}</div>
          </div>
        ))}
      </div>

      <div className="panel">
        <h3 className="text-base font-display mb-4">Reminders</h3>
        {paymentsDue.length === 0 && upcoming.length === 0 && <p className="text-sm text-muted">All caught up — no pending items.</p>}
        <div className="space-y-2.5">
          {paymentsDue.map((b) => (
            <div key={b.id} className="flex gap-2.5 bg-ivory rounded-lg p-3 text-sm">
              <span className="w-2 h-2 rounded-full bg-red mt-1.5 flex-shrink-0" />
              <div>
                <b>Balance pending — {b.customerName}</b>
                <div className="text-xs text-muted">{HALL_LABEL[b.hallAllocation]} · {niceDate(b.eventDate.slice(0, 10))} · Due {money(b.totalAmount - b.advanceAmount)}</div>
              </div>
            </div>
          ))}
          {upcoming.map((b) => (
            <div key={b.id} className="flex gap-2.5 bg-ivory rounded-lg p-3 text-sm">
              <span className="w-2 h-2 rounded-full bg-gold mt-1.5 flex-shrink-0" />
              <div>
                <b>{b.eventDate.slice(0, 10) === todayStr ? "Today's event" : "Upcoming event"} — {b.customerName}</b>
                <div className="text-xs text-muted">{HALL_LABEL[b.hallAllocation]} · {b.functionType} · {niceDate(b.eventDate.slice(0, 10))}, {b.slot}</div>
              </div>
            </div>
          ))}
        </div>
        <Link href="/calendar" className="btn btn-outline mt-4 inline-block">Open calendar</Link>
      </div>
    </div>
  );
}
