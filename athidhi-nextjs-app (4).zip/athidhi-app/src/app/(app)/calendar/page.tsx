"use client";
import { useEffect, useState, useCallback } from "react";
import { SLOTS } from "@/lib/constants";
import BookingFormModal, { BookingDraft } from "@/components/BookingFormModal";
import SlotModal from "@/components/SlotModal";
import DetailsModal from "@/components/DetailsModal";

type DayData = {
  isPast: boolean;
  slots: Record<string, { hall1: string; hall2: string; bookings: any[] }>;
};

function fmtDate(y: number, m: number, d: number) {
  return `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}

export default function CalendarPage() {
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth() + 1); // 1-12
  const [days, setDays] = useState<Record<string, DayData>>({});
  const [loading, setLoading] = useState(true);

  const [slotModal, setSlotModal] = useState<{ date: string; slot: string } | null>(null);
  const [formDraft, setFormDraft] = useState<{ draft: BookingDraft; mode: "create" | "edit" } | null>(null);
  const [detailsId, setDetailsId] = useState<string | null>(null);

  const load = useCallback(() => {
    setLoading(true);
    fetch(`/api/availability?year=${year}&month=${month}`)
      .then((r) => r.json())
      .then((d) => setDays(d.days || {}))
      .finally(() => setLoading(false));
  }, [year, month]);

  useEffect(() => { load(); }, [load]);

  function prevMonth() { if (month === 1) { setMonth(12); setYear(year - 1); } else setMonth(month - 1); }
  function nextMonth() { if (month === 12) { setMonth(1); setYear(year + 1); } else setMonth(month + 1); }
  function goToday() { setYear(now.getFullYear()); setMonth(now.getMonth() + 1); }

  const monthLabel = new Date(year, month - 1, 1).toLocaleDateString("en-IN", { month: "long", year: "numeric" });
  const daysInMonth = new Date(year, month, 0).getDate();
  const startDow = new Date(year, month - 1, 1).getDay();
  const todayStr = fmtDate(now.getFullYear(), now.getMonth() + 1, now.getDate());

  const dotClass: Record<string, string> = {
    green: "hall-dot hall-dot-green", orange: "hall-dot hall-dot-orange", red: "hall-dot hall-dot-red", grey: "hall-dot hall-dot-grey",
  };

  function refreshAndCloseModals() {
    load();
    setSlotModal(null);
    setFormDraft(null);
    setDetailsId(null);
  }

  async function handleConvert(id: string) {
    const res = await fetch(`/api/bookings/${id}/convert`, { method: "POST" });
    if (res.ok) refreshAndCloseModals();
    else alert((await res.json()).error);
  }
  async function handleDelete(id: string) {
    if (!confirm("Delete this enquiry?")) return;
    const res = await fetch(`/api/bookings/${id}`, { method: "DELETE" });
    if (res.ok) { load(); if (slotModal) { /* keep slot modal open, refreshed on next data load */ } }
  }

  return (
    <div>
      <div className="panel">
        <div className="flex justify-between items-center flex-wrap gap-3.5 mb-4">
          <div className="flex items-center gap-3">
            <button className="w-8 h-8 rounded-lg border border-line" onClick={prevMonth}>‹</button>
            <div className="font-display text-lg min-w-[170px] text-center">{monthLabel}</div>
            <button className="w-8 h-8 rounded-lg border border-line" onClick={nextMonth}>›</button>
            <button className="btn btn-outline !py-1.5 !px-3 !text-xs" onClick={goToday}>Today</button>
          </div>
          <div className="flex gap-4 text-xs text-muted flex-wrap">
            <span className="flex items-center gap-1.5"><i className="w-2.5 h-2.5 rounded-[3px] bg-green inline-block" />Available</span>
            <span className="flex items-center gap-1.5"><i className="w-2.5 h-2.5 rounded-[3px] bg-orange inline-block" />Tentative</span>
            <span className="flex items-center gap-1.5"><i className="w-2.5 h-2.5 rounded-[3px] bg-red inline-block" />Booked</span>
            <span className="flex items-center gap-1.5"><i className="w-2.5 h-2.5 rounded-[3px] bg-grey inline-block" />Past date</span>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-2">
          {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
            <div key={d} className="text-center text-[11px] text-muted font-bold uppercase pb-1.5">{d}</div>
          ))}
          {Array.from({ length: startDow }).map((_, i) => <div key={"e" + i} />)}
          {Array.from({ length: daysInMonth }).map((_, i) => {
            const d = i + 1;
            const ds = fmtDate(year, month, d);
            const day = days[ds];
            const isToday = ds === todayStr;
            const fully = day && !day.isPast && SLOTS.every((s) => day.slots[s]?.hall1 === "red" && day.slots[s]?.hall2 === "red");

            return (
              <div
                key={ds}
                className={`min-h-[104px] rounded-lg p-2 border flex flex-col gap-1.5
                  ${fully ? "bg-redBg border-red/30" : "border-line"}
                  ${day?.isPast ? "bg-greyBg" : ""}
                  ${isToday ? "outline outline-2 outline-gold -outline-offset-2" : ""}`}
              >
                <div className="flex justify-between items-center">
                  <span className="font-bold text-sm">{d}</span>
                  {fully && <span className="text-[10px] font-bold uppercase bg-red text-white px-1.5 py-0.5 rounded">Full</span>}
                </div>
                {day?.isPast ? (
                  <div className="text-[11px] text-muted">Past date</div>
                ) : (
                  day && SLOTS.map((slot) => (
                    <div
                      key={slot}
                      className="flex items-center gap-1.5 px-1.5 py-1 rounded-md cursor-pointer hover:bg-ivory text-xs"
                      onClick={(e) => { e.stopPropagation(); setSlotModal({ date: ds, slot }); }}
                    >
                      <span className="text-[10px] font-bold text-muted w-4">{slot === "Morning" ? "AM" : "PM"}</span>
                      <span className={dotClass[day.slots[slot]?.hall1 || "green"]} />
                      <span className={dotClass[day.slots[slot]?.hall2 || "green"]} />
                    </div>
                  ))
                )}
              </div>
            );
          })}
        </div>
      </div>
      <p className="text-xs text-muted">Each date shows Morning (AM) and Evening (PM) slots. Each dot is Hall 1 / Hall 2 availability for that slot. Click a slot to view or add a booking.</p>

      {slotModal && days[slotModal.date] && (
        <SlotModal
          date={slotModal.date}
          slot={slotModal.slot}
          hall1={days[slotModal.date].slots[slotModal.slot].hall1 as any}
          hall2={days[slotModal.date].slots[slotModal.slot].hall2 as any}
          bookings={days[slotModal.date].slots[slotModal.slot].bookings}
          onClose={() => setSlotModal(null)}
          onConvert={handleConvert}
          onDelete={handleDelete}
          onEdit={(id) => {
            const b = days[slotModal.date].slots[slotModal.slot].bookings.find((x) => x.id === id);
            setFormDraft({ draft: { ...b, eventDate: slotModal.date, slot: slotModal.slot }, mode: "edit" });
          }}
          onViewDetails={(id) => setDetailsId(id)}
          onAddNew={() => setFormDraft({ draft: { eventDate: slotModal.date, slot: slotModal.slot }, mode: "create" })}
        />
      )}

      {formDraft && (
        <BookingFormModal
          draft={formDraft.draft}
          mode={formDraft.mode}
          onClose={() => setFormDraft(null)}
          onSaved={refreshAndCloseModals}
        />
      )}

      {detailsId && (
        <DetailsModal
          id={detailsId}
          onClose={() => setDetailsId(null)}
          onEdit={(b) => { setDetailsId(null); setFormDraft({ draft: { ...b, eventDate: b.eventDate.slice(0, 10) }, mode: "edit" }); }}
          onCompleted={refreshAndCloseModals}
          onCancelled={refreshAndCloseModals}
        />
      )}
    </div>
  );
}
