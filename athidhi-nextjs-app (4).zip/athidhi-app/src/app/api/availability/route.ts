import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { computeHallSlotStatus } from "@/lib/rules";

// GET /api/availability?year=2026&month=7  (month is 1-12)
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const year = Number(searchParams.get("year"));
  const month = Number(searchParams.get("month")); // 1-12

  if (!year || !month) {
    return NextResponse.json({ error: "year and month are required" }, { status: 400 });
  }

  const start = new Date(Date.UTC(year, month - 1, 1));
  const end = new Date(Date.UTC(year, month, 1)); // first day of next month (exclusive)

  const bookings = await prisma.booking.findMany({
    where: { eventDate: { gte: start, lt: end } },
    select: {
      id: true,
      eventDate: true,
      slot: true,
      hallAllocation: true,
      status: true,
      customerName: true,
      functionType: true,
      guests: true,
      advanceAmount: true,
      totalAmount: true,
    },
  });

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const daysInMonth = new Date(Date.UTC(year, month, 0)).getUTCDate();
  const days: Record<string, any> = {};

  for (let d = 1; d <= daysInMonth; d++) {
    const dateObj = new Date(Date.UTC(year, month - 1, d));
    const dateStr = dateObj.toISOString().slice(0, 10);
    const isPast = dateObj < today;

    const dayResult: Record<string, any> = { isPast, slots: {} };
    for (const slot of ["Morning", "Evening"] as const) {
      const onThisSlot = bookings.filter(
        (b) => b.eventDate.toISOString().slice(0, 10) === dateStr && b.slot === slot
      );
      const hall1 = computeHallSlotStatus(1, onThisSlot, isPast);
      const hall2 = computeHallSlotStatus(2, onThisSlot, isPast);
      dayResult.slots[slot] = {
        hall1,
        hall2,
        bookings: onThisSlot
          .filter((b) => b.status !== "Lost" && b.status !== "Cancelled")
          .map((b) => ({
            id: b.id,
            customerName: b.customerName,
            functionType: b.functionType,
            guests: b.guests,
            hallAllocation: b.hallAllocation,
            status: b.status,
            advanceAmount: b.advanceAmount,
            totalAmount: b.totalAmount,
          })),
      };
    }
    days[dateStr] = dayResult;
  }

  return NextResponse.json({ days });
}
