import { NextRequest, NextResponse } from "next/server";
import { createSession, findStaff, verifyPassword } from "@/lib/auth";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const username = body?.username as string | undefined;
  const password = body?.password as string | undefined;

  if (!username || !password || !verifyPassword(password)) {
    return NextResponse.json({ error: "Incorrect password" }, { status: 401 });
  }

  const staff = findStaff(username);
  if (!staff) {
    return NextResponse.json({ error: "Unknown staff member" }, { status: 401 });
  }

  await createSession(staff);
  return NextResponse.json({ user: staff });
}
