import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { syncBookingToSheet } from "@/lib/sheets";

export async function POST(_req: NextRequest, { params }: { params: { id: string } }) {
  const existing = await prisma.booking.findUnique({ where: { id: params.id } });
  if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (existing.status !== "Confirmed") {
    return NextResponse.json({ error: "Only confirmed bookings can be marked completed." }, { status: 400 });
  }
  const booking = await prisma.booking.update({
    where: { id: params.id },
    data: { status: "Completed", history: { create: { action: "Event completed" } } },
  });
  await syncBookingToSheet(booking);
  return NextResponse.json({ booking });
}
