import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { allocationFor, hallNumsFor, hasConfirmedConflict } from "@/lib/rules";
import { syncBookingToSheet } from "@/lib/sheets";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const booking = await prisma.booking.findUnique({
    where: { id: params.id },
    include: { history: { orderBy: { createdAt: "asc" } } },
  });
  if (!booking) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ booking });
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const existing = await prisma.booking.findUnique({ where: { id: params.id } });
  if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const body = await req.json();
  const hallAllocation = allocationFor(Number(body.guests), Number(body.hallId) === 2 ? 2 : 1);
  const occupied = hallNumsFor(hallAllocation);
  const date = new Date(body.eventDate);

  if (existing.status === "Confirmed" || existing.status === "Completed") {
    const conflict = await hasConfirmedConflict(occupied, date, body.slot, existing.id);
    if (conflict) {
      return NextResponse.json(
        { error: "Cannot save: the required hall is already confirmed booked for that date & slot by another booking." },
        { status: 409 }
      );
    }
  }

  const booking = await prisma.booking.update({
    where: { id: params.id },
    data: {
      customerName: body.customerName,
      mobile: body.mobile,
      location: body.location,
      functionType: body.functionType,
      eventDate: date,
      slot: body.slot,
      guests: Number(body.guests),
      hallAllocation,
      foodPref: body.foodPref,
      menuPackage: body.menuPackage,
      specialReq: body.specialReq,
      totalAmount: Number(body.totalAmount) || 0,
      advanceAmount: Number(body.advanceAmount) || 0,
      paymentMode: body.paymentMode,
      source: body.source,
      remarks: body.remarks,
      history: { create: { action: "Details updated" } },
    },
  });

  await syncBookingToSheet(booking);
  return NextResponse.json({ booking });
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const existing = await prisma.booking.findUnique({ where: { id: params.id } });
  if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (existing.status !== "Enquiry" && existing.status !== "Lost") {
    return NextResponse.json({ error: "Only enquiries can be deleted. Cancel a confirmed booking instead." }, { status: 400 });
  }
  await prisma.booking.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
