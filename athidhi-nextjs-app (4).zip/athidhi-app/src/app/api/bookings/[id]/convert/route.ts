import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { hallNumsFor, hasConfirmedConflict, rejectOverlappingEnquiries } from "@/lib/rules";
import { syncBookingToSheet } from "@/lib/sheets";

export async function POST(_req: NextRequest, { params }: { params: { id: string } }) {
  const existing = await prisma.booking.findUnique({ where: { id: params.id } });
  if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (existing.status !== "Enquiry") {
    return NextResponse.json({ error: "Only open enquiries can be converted." }, { status: 400 });
  }

  const occupied = hallNumsFor(existing.hallAllocation);
  const conflict = await hasConfirmedConflict(occupied, existing.eventDate, existing.slot, existing.id);
  if (conflict) {
    return NextResponse.json(
      { error: "This hall/slot has already been confirmed booked by another enquiry." },
      { status: 409 }
    );
  }

  const booking = await prisma.booking.update({
    where: { id: params.id },
    data: {
      status: "Confirmed",
      history: { create: { action: "Converted to booking", note: "Advance payment received" } },
    },
  });

  await rejectOverlappingEnquiries(booking);
  await syncBookingToSheet(booking);

  return NextResponse.json({ booking });
}
