import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { allocationFor, hallNumsFor, hasConfirmedConflict, rejectOverlappingEnquiries } from "@/lib/rules";
import { syncBookingToSheet } from "@/lib/sheets";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const status = searchParams.get("status"); // comma-separated list, e.g. "Confirmed,Completed"
  const hall = searchParams.get("hall"); // "Hall1" | "Hall2" | "BothHalls"
  const slot = searchParams.get("slot"); // "Morning" | "Evening"
  const date = searchParams.get("date"); // "YYYY-MM-DD"
  const search = searchParams.get("search");

  const bookings = await prisma.booking.findMany({
    where: {
      ...(status ? { status: { in: status.split(",") as any } } : {}),
      ...(hall ? { hallAllocation: hall as any } : {}),
      ...(slot ? { slot: slot as any } : {}),
      ...(date ? { eventDate: new Date(date) } : {}),
      ...(search
        ? {
            OR: [
              { customerName: { contains: search, mode: "insensitive" } },
              { mobile: { contains: search } },
            ],
          }
        : {}),
    },
    orderBy: { eventDate: "desc" },
  });

  return NextResponse.json({ bookings });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const {
    customerName,
    mobile,
    location,
    functionType,
    eventDate,
    slot,
    guests,
    hallId, // 1 or 2, as chosen in the form (ignored if guests > threshold)
    foodPref,
    menuPackage,
    specialReq,
    totalAmount,
    advanceAmount,
    paymentMode,
    source,
    remarks,
    status, // "Enquiry" | "Confirmed"
  } = body;

  if (!customerName || !mobile || !eventDate || !slot || !guests) {
    return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
  }

  const hallAllocation = allocationFor(Number(guests), Number(hallId) === 2 ? 2 : 1);
  const occupied = hallNumsFor(hallAllocation);
  const date = new Date(eventDate);

  const conflict = await hasConfirmedConflict(occupied, date, slot);
  if (conflict && status === "Confirmed") {
    return NextResponse.json(
      { error: `${hallAllocation === "BothHalls" ? "Both Halls" : hallAllocation} already booked for this date & slot.` },
      { status: 409 }
    );
  }
  // For enquiries we allow saving even if the hall is already confirmed elsewhere
  // (the person may want to be logged as a backup/waitlist request) - the frontend
  // warns the user about this before submitting.

  const booking = await prisma.booking.create({
    data: {
      customerName,
      mobile,
      location,
      functionType,
      eventDate: date,
      slot,
      guests: Number(guests),
      hallAllocation,
      foodPref,
      menuPackage,
      specialReq,
      totalAmount: Number(totalAmount) || 0,
      advanceAmount: Number(advanceAmount) || 0,
      paymentMode,
      source,
      remarks,
      status: status === "Confirmed" ? "Confirmed" : "Enquiry",
      history: {
        create: {
          action: status === "Confirmed" ? "Booking created (direct)" : "Enquiry created",
        },
      },
    },
  });

  if (booking.status === "Confirmed") {
    await rejectOverlappingEnquiries(booking);
  }

  await syncBookingToSheet(booking);

  return NextResponse.json({ booking }, { status: 201 });
}
