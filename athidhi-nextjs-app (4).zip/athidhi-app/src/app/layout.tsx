import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Athidhi — Banquet Hall Reservation Management",
  description: "Internal staff tool for managing banquet hall enquiries and bookings.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
