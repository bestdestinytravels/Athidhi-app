"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

const STAFF = [
  { username: "ashwin", label: "Ashwin — Admin" },
  { username: "shiva", label: "Shiva — Manager" },
];

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("ashwin");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });
    setLoading(false);
    if (!res.ok) {
      setError("Incorrect password. Please try again.");
      return;
    }
    router.push("/dashboard");
    router.refresh();
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-ink">
      <div className="bg-white w-[380px] max-w-[92vw] rounded-2xl shadow-2xl p-10 text-center">
        <div className="font-display text-3xl text-goldDeep">Athidhi</div>
        <div className="text-xs text-muted uppercase tracking-widest mb-6 mt-1">Banquet Hall Reservation Desk</div>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4 text-left">
          <div>
            <label className="label">Staff member</label>
            <select className="input" value={username} onChange={(e) => setUsername(e.target.value)}>
              {STAFF.map((s) => (
                <option key={s.username} value={s.username}>{s.label}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">Password</label>
            <input
              type="password"
              className="input"
              placeholder="Enter password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <button type="submit" disabled={loading} className="btn btn-gold w-full">
            {loading ? "Signing in…" : "Sign in"}
          </button>
          {error && <p className="text-red text-xs">{error}</p>}
        </form>
        <p className="text-[11px] text-muted mt-4">Internal staff tool.</p>
      </div>
    </div>
  );
}
